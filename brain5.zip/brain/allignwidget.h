#ifndef ALLIGNWIDGET_H
#define ALLIGNWIDGET_H
#include "widget.h"
#include "simpleobject3d.h"
class AllignWidget: public Widget
{
public:
    AllignWidget(QWidget *parent = nullptr);
    void push(SimpleObject3D* a)
    {
        objects.push_back(a);
        update();
    }
    void paintGL();
    void mouseDoubleClickEvent ( QMouseEvent * e );
};

#endif // ALLIGNWIDGET_H
