#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include "dialog.h"
#include "dialog2.h"
#include "allignwindow.h"
#include "simpleobject3d.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect (this, SIGNAL (updater(QString)),
             ui->openGLWidget, SLOT(loadObj(QString)));
    connect (this, SIGNAL (cutter()),
             ui->openGLWidget, SLOT(cutter()));
    connect (this, SIGNAL (adder()),
             ui->openGLWidget, SLOT(adder()));
    connect (this, SIGNAL (transparent(int)),
             ui->openGLWidget, SLOT(transparent(int)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,
                       tr("Open Mesh"), QDir::currentPath(),
                       tr("Model File(*.obj)"));
    if(!filename.isEmpty())
        emit updater(filename);
}

void MainWindow::on_pushButton_2_clicked()
{
    if(!(ui->openGLWidget->canCut()))
    {
        QMessageBox::warning(this,"Warning","You must turn off transparency of models.");
        return;
    }
    (ui->openGLWidget)->cutFlag=1;
    (ui->openGLWidget)->cutVertexes.clear();
}

void MainWindow::on_pushButton_3_clicked()
{
    (ui->openGLWidget)->cutFlag=0;
    emit cutter();
}

void MainWindow::on_pushButton_4_clicked()
{
    (ui->openGLWidget)->cutFlag=0;
    emit adder();
}

void MainWindow::on_pushButton_5_clicked()
{
    Dialog *d=new Dialog(nullptr,ui->openGLWidget->getSectionsSize());
    connect (d, SIGNAL (connecting(unsigned int,unsigned int)),
             ui->openGLWidget, SLOT(connecting(unsigned int,unsigned int)));
    d->show();
}

void MainWindow::on_pushButton_6_clicked()
{
    Dialog2 *d=new Dialog2();
    AllignWindow *e=new AllignWindow();
    d->objects=ui->openGLWidget->getAllModels();
    d->tool=e;
    connect (d, SIGNAL (startalligning(SimpleObject3D*,SimpleObject3D*,int, int)),
             e, SLOT(getModels(SimpleObject3D*,SimpleObject3D*, int, int)));
    connect (e, SIGNAL (ok(QVector<QVector3D>,QVector<QVector3D>, int, int)),
             ui->openGLWidget, SLOT(alligning(QVector<QVector3D>,QVector<QVector3D>,int,int)));
    d->show();
}

void MainWindow::on_pushButton_8_clicked()
{
    emit(transparent(1));
}

void MainWindow::on_pushButton_9_clicked()
{
    emit(transparent(2));
}

void MainWindow::on_pushButton_7_clicked()
{
    emit(transparent(3));
}
