#ifndef ALLIGNWINDOW_H
#define ALLIGNWINDOW_H

#include <QMainWindow>
#include "simpleobject3d.h"
namespace Ui {
class AllignWindow;
}

class AllignWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AllignWindow(QWidget *parent = nullptr);
    ~AllignWindow();
public slots:
    void getModels(SimpleObject3D* a,SimpleObject3D* b);
private slots:
    void on_pushButton_clicked();
signals:
    void ok(QVector<QVector3D>,QVector<QVector3D>);
private:
    Ui::AllignWindow *ui;
};

#endif // ALLIGNWINDOW_H
