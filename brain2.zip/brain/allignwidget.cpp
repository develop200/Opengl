#include "allignwidget.h"
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <QOpenGLExtraFunctions>
AllignWidget::AllignWidget(QWidget *parent): Widget(parent)
{
}

void AllignWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);//очищаем буферцвета и глубины
    //нужно загрузить матрицу проекций  и модельно видовую матрицу в shader
    ViewMatrix1.setToIdentity();
    ViewMatrix2.setToIdentity();
    ViewMatrix1.translate(x,y,z);//отодвигаем матрицу на 5
    ViewMatrix2.rotate(rotation);
    ViewMatrix=ViewMatrix1*ViewMatrix2;
    program.bind();
    program.setUniformValue("u_projectionMatrix",projectionMatrix);
    program.setUniformValue("u_viewMatrix",ViewMatrix);
    program.setUniformValue("u_lightPosition",QVector4D(0.0,0.0,0.0,1.0));
    program.setUniformValue("u_lightPower",6.0f);
    for(int i=0;i<objects.size();i++)
    {
        objects[i]->draw(&program,context()->functions());
    }
    for(int i=0;i<sections.size();i++)
    {
        sections[i]->draw(&program,context()->functions());
    }
    for(int i=0;i<tracks.size();i++)
    {
        tracks[i]->draw(&program,context()->functions());
    }
    if(isCutting)
    {
        QOpenGLContext *ctx=QOpenGLContext::currentContext();
        if(mFBO)
            delete mFBO;
        QOpenGLFramebufferObjectFormat format;
        format.setSamples(0);
        format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
        mFBO=new QOpenGLFramebufferObject(size(),format);
        glBindFramebuffer(GL_READ_FRAMEBUFFER,defaultFramebufferObject());
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,mFBO->handle());
        ctx->extraFunctions()->glBlitFramebuffer(0,0,width(),height(),0,0,mFBO->width(),mFBO->height(),GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT,GL_NEAREST);
        mFBO->bind();
        float depth;
        if(mouseclick.size()==1 && tr_cutVertexes.size()>0)
        {
            cutVertexes=cutVertexes+tr_cutVertexes;
            tr_cutVertexes.clear();
        }
        for(int i=0;i<mouseclick.size();i++)
        {
            glReadPixels(mouseclick[i].x(),height()-mouseclick[i].y(),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&depth);
            if(depth>=1)
                return;
            float zNorm=2*depth-1;
            float zView=2*0.01*50/((50-0.01)*zNorm-0.01-50);
            depth=zView-z;
            QVector4D tmp(2.0f*mouseclick[i].x()/width()-1.0f,-2.0f*mouseclick[i].y()/height()+1.0f,-1.0f,1.0f);
            QVector4D tmp2((projectionMatrix.inverted()*tmp).toVector2D(),-1.0f,0.0f);//вектор направления клика мышью
            QVector3D direction((ViewMatrix1.inverted()*tmp2).toVector3D().normalized());//вектор направления клика мышью
                                                                                            //в мировой СК
            QVector3D camPos((ViewMatrix1.inverted()*QVector4D(0.0f,0.0f,0.0f,1.0f)).toVector3D());
            QVector3D N(0.0f,0.0f,1.0f);
            float t=QVector3D::dotProduct(QVector3D(camPos.x(),camPos.y(),depth-camPos.z()),N)/QVector3D::dotProduct(direction,N);
            QVector3D result=camPos+direction*t;
            if(i==0)
                cutVertexes.append(ViewMatrix2.inverted()*result);
            if(i==1)
                tr_cutVertexes.push_front(ViewMatrix2.inverted()*result);
        }
        mouseclick.clear();
        mFBO->release();
        isCutting=false;
    }
}

void AllignWidget::mouseDoubleClickEvent(QMouseEvent *event)
{
    if(event->buttons()==Qt::LeftButton)
    {
        mouseclick.push_back(QVector2D(event->localPos()));
        isCutting=true;
        z+=0.000001f;
        update();
    }
}
