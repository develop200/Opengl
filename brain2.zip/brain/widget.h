#ifndef WIDGET_H
#define WIDGET_H

#include <QOpenGLWidget>
#include <QMatrix4x4>
#include <QOpenGLShaderProgram>
#include <QOpenGLTexture>
#include <QOpenGLBuffer>
#include <QMouseEvent>
#include "simpleobject3d.h"
#include <QOpenGLContext>
#include <QOpenGLFramebufferObject>
#include <QOpenGLFunctions>

class Widget : public QOpenGLWidget, public QOpenGLFunctions
{
    Q_OBJECT
public slots:
    void updater()
    {
        update();
    }
public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    int cutFlag=0;
    bool isCutting;
    QVector<QVector3D> cutVertexes;
    QVector<QVector3D> tr_cutVertexes;
public slots:
    void loadObj(QString path);
    void cutter();
    bool checkBelonging(float _pointX, float _pointY);
    bool checkDistance(QVector3D a, QVector3D b, QVector3D c);
    void finder();
    void connecting(unsigned int a,unsigned int b);
    void alligning(QVector<QVector3D>,QVector<QVector3D>);
    QVector<SimpleObject3D*> getAllModels();
protected:
    void initializeGL();
    void resizeGL(int w,int h);//вызывается при изменении размера окна
    void paintGL();//вызывается каждый раз при перерисовке содержимого окна
    void initShaders();

    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent* event);
protected:
    QMatrix4x4 projectionMatrix;
    QMatrix4x4 ViewMatrix1;
    QMatrix4x4 ViewMatrix2;
    QMatrix4x4 ViewMatrix;
    QOpenGLShaderProgram program;

    QVector2D mousePosition;
    QQuaternion rotation;
    QVector<SimpleObject3D*> objects;
    QVector<SimpleObject3D*> sections;
    QVector<SimpleObject3D*> tracks;

    float z;//сдвиг по оси z камеры
    float x;//сдвиг по x
    float y;//сдвиг по y
    QOpenGLFramebufferObject *mFBO=0;

    //вспомогательные для расчёта z-буфера в paintGL
    QVector<QVector2D> mouseclick;
};
#endif // WIDGET_H
