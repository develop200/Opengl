#include "allignwindow.h"
#include "ui_allignwindow.h"
#include <QMessageBox>
AllignWindow::AllignWindow(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::AllignWindow)
{
    ui->setupUi(this);
}

AllignWindow::~AllignWindow()
{
    delete ui;
}

void AllignWindow::getModels(SimpleObject3D *a, SimpleObject3D *b)
{
    ui->openGLWidget->push(a);
    ui->openGLWidget_2->push(b);
}

void AllignWindow::on_pushButton_clicked()
{
    if(ui->openGLWidget->cutVertexes.size()!=4 || ui->openGLWidget_2->cutVertexes.size()!=4)
    {
        QMessageBox::warning(this,"Warning","You must choose 4 vertwxes in each model.");
        return;
    }
    emit ok(ui->openGLWidget->cutVertexes,ui->openGLWidget_2->cutVertexes);
    close();
}
