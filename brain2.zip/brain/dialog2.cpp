#include "dialog2.h"
#include "ui_dialog2.h"
#include "allignwindow.h"
#include <QMessageBox>
Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);
}

Dialog2::~Dialog2()
{
    delete ui;
}

void Dialog2::on_pushButton_clicked()
{
    QString a=ui->lineEdit->text();
    QString b=ui->lineEdit_2->text();
    int c=a.toUInt();
    int d=b.toUInt();
    if(c>objects.size() || d>objects.size() || c<1 || d<1)
    {
        QMessageBox::warning(this,"Warning","You must choose loaded models.");
        return;
    }
    else
    {
        emit startalligning(objects[c-1],objects[d-1]);
        close();
        tool->show();
    }
}
