#ifndef ALLIGNWIDGET_H
#define ALLIGNWIDGET_H
#include "widget.h"
#include "simpleobject3d.h"
class AllignWidget: public Widget
{
public:
    AllignWidget(QWidget *parent = nullptr);
    void push(SimpleObject3D* a)
    {
        objects.push_back(a);
        update();
    }
    void paintGL();
    void mouseDoubleClickEvent ( QMouseEvent * e );
};

#endif // ALLIGNWIDGET_H
/*
#include "mainwindow.h"
#include <QApplication>
#include<QVector>
#include<QVector3D>
#include<cmath>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}

float distance(float x1,float y1,float z1,float x2,float y2,float z2)
{
    return pow(pow(x2-x1,2)+pow(y2-y1,2)+pow(z2-z1,2),1/2);
}

float angle(float x1,float y1,float z1,float x2,float y2,float z2,float x3,float y3,float z3,int sign)
{
    float vec_a_x = x2-x1;
    float vec_a_y = y2-y1;
    float vec_a_z = z2-z1;
    float vec_b_x = x3-x1;
    float vec_b_y = y3-y1;
    float vec_b_z = z3-z1;
    float chisl = vec_a_x*vec_b_x + vec_a_y*vec_b_y + vec_a_z*vec_b_z;
    float dist_a = pow(pow(vec_a_x,2)+pow(vec_a_y,2)+pow(vec_a_z,2),1/2);
    float dist_b = pow(pow(vec_b_x,2)+pow(vec_b_y,2)+pow(vec_b_z,2),1/2);
    return chisl/(dist_a*dist_b);
}

int first_connect_of_two_points(int start_of_second_mas,QVector<QVector3D> f,int i)
{
    int space = start_of_second_mas;
    int point = space;
    float mini = distance(f[i].x(),f[i].y(),f[i].z(),f[space].x(),f[space].y(),f[space].z());
    float x1 = f[0].x();
    float y1 = f[0].y();
    float z1 = f[0].z();
    for(int j=space;j<f.size();j++)
    {
        float x2 = f[j].x();
        float y2 = f[j].y();
        float z2 = f[j].z();
        float d = distance(x1,y1,z1,x2,y2,z2);
        if(mini<d)
        {
            mini=d;
            point = j;
        }
    }
    return point;
}

float perimetr(float x1,float y1,float z1,float x2,float y2,float z2,float x3,float y3,float z3)
{
    float a = distance(x1,y1,z1,x2,y2,z2);
    float b = distance(x2,y2,z2,x3,y3,z3);
    float c = distance(x1,y1,z1,x3,y3,z3);
    return a+b+c;
}


void other_point(QVector<QVector3D> f,QVector<bool> &sig,QVector<QString> &ans,int space)
{
    int le = ans.size()-1;
    for(int i=space;i<f.size();i++)
    {
        if(!sig[i])
        {
            float mini = distance(f[0].x(),f[0].y(),f[0].z(),f[i].x(),f[i].y(),f[i].z());
            int point=0;
            float x2 = f[i].x();
            float y2 = f[i].y();
            float z2 = f[i].z();
            for(int j=0;j<space;j++)
            {
                float x1 = f[j].x();
                float y1 = f[j].y();
                float z1 = f[j].z();
                float d = distance(x1,y1,z1,x2,y2,z2);
                if(mini<d)
                {
                    mini=d;
                    point = j;
                }
            }
            ans.resize(ans.size()+1);
            int third_point;
            if(point+1!=space)
            {
                third_point = point+1;
            }
            else
            {
                third_point = 0;
            }
            ans[le]= QString::number(i) + ' ' + QString::number(point)+' ' + QString::number(third_point);
        }
    }
}

void function(QVector<QVector3D> a, QVector<QVector3D> b)
{
    QVector<QVector3D> f;
    QVector<bool> sig;
    QVector<QString> ans;
    int ind_of_ans=0;
    const double PI = acos(-1.0);
    int space;
    if(a.size() <= b.size())
    {
        f = a + b;
        space = a.size();
    }
    else
    {
        f = b + a;
        space = b.size();
    }
    sig.insert(0, f.size(), false);
    int start_of_second_mas = space;
    int point = first_connect_of_two_points(start_of_second_mas,f,0);
    for(int i=0;i<space-1;)
    {
            sig[point]=true;
            sig[i]=true;
            float x1 = f[i].x();
            float y1 = f[i].y();
            float z1 = f[i].z();
            float x3 = f[i+1].x();
            float y3 = f[i+1].y();
            float z3 = f[i+1].z();
            float x3_2,y3_2,z3_2;
            int thrird_point, right = 1,left = 0;
            if((f.size()-space)-1>point && space<point)
            {
                thrird_point = point+right;
                x3_2 = f[thrird_point].x();
                y3_2 = f[thrird_point].y();
                z3_2 = f[thrird_point].z();
                right+=1;
            }
            else
            {
                thrird_point = space+left;
                x3_2 = f[thrird_point].x();
                y3_2 = f[thrird_point].y();
                z3_2 = f[thrird_point].z();
                left+=1;
            }
            float ang_1 =  acos(angle(x1,y1,z1,f[point].x(),f[point].y(),f[point].z(),x3_2,y3_2,z3_2,1)) * 180.0 / PI;
            float ang_2 =  acos(angle(x1,y1,z1,f[point].x(),f[point].y(),f[point].z(),x3,y3,z3,0)) * 180.0 / PI;
            ans.resize(ans.size()+1);
            if(ang_1>90 && ang_2<=90)
            {
                sig[i+1]=true;
                ans[ind_of_ans]= QString::number(i) + ' ' + QString::number(point)+' ' + QString::number(i+1);
                i++;
            }
            else if (ang_1<=90 && ang_2>90)
            {
                sig[thrird_point]=true;
                ans[ind_of_ans]= QString::number(i) + ' ' + QString::number(point)+' ' + QString::number(thrird_point);
            }
            else if (ang_1<=90 && ang_2<=90)
            {
                float per_1 = perimetr(x1,y1,z1,f[point].x(),f[point].y(),f[point].z(),x3_2,y3_2,z3_2);
                float per_2 = perimetr(x1,y1,z1,f[point].x(),f[point].y(),f[point].z(),x3,y3,z3);
                if(per_1<=per_2)
                {
                    sig[thrird_point]=true;
                    ans[ind_of_ans]= QString::number(i) + ' ' + QString::number(point)+' ' + QString::number(thrird_point);
                }
                else
                {
                    sig[i+1]=true;
                    ans[ind_of_ans]= QString::number(i) + ' ' + QString::number(point)+' ' + QString::number(i+1);
                    i++;
                }
            }
            point = thrird_point;
    }
    other_point(f,sig,ans,space);
}
*/
