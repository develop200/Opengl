#include "dialog.h"
#include "ui_dialog.h"
#include <QMessageBox>
Dialog::Dialog(QWidget *parent,int i) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    size=i;
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    QString a=ui->lineEdit->text();
    QString b=ui->lineEdit_2->text();
    c=a.toUInt();
    d=b.toUInt();
    if(c>size || d>size || c<1 || d<1)
    {
        QMessageBox::warning(this,"Warning","You must choose correct sections.");
        return;
    }
    emit connecting(c,d);
    close();
}
