#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
signals:
    void connecting(unsigned int a,unsigned int b);
public:
    explicit Dialog(QWidget *parent = nullptr,int i=0);
    ~Dialog();
    unsigned int c,d;

private slots:
    void on_pushButton_clicked();

private:
    Ui::Dialog *ui;
    int size;
};

#endif // DIALOG_H
