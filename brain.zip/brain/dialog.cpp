#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    QString a=ui->lineEdit->text();
    QString b=ui->lineEdit_2->text();
    c=a.toUInt();
    d=b.toUInt();
    emit connecting(c,d);
    close();
}
