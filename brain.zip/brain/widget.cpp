#include "widget.h"
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <QOpenGLExtraFunctions>
#include <QMessageBox>

Widget::Widget(QWidget *parent)
    : QOpenGLWidget(parent)
{
    z=-5.0f;
    isCutting=false;
}

Widget::~Widget()
{
}

void Widget::initializeGL()
{
    initializeOpenGLFunctions();
    glClearColor(0.0f,0.0f,0.0f,1.0f);//очистка экрана
    glEnable(GL_DEPTH_TEST);//включить буфер глубины
    glEnable(GL_CULL_FACE);//задние грани не будут рисоваться
    initShaders();//загрузка исх кодов шейдеров и компиляция их
}
void Widget::resizeGL(int w,int h)
{
    float aspect=(float)w/(float)h;
    projectionMatrix.setToIdentity();//сделали единичной
    projectionMatrix.perspective(45,aspect,0.01f,50.0f);//2 числа это плоскости отсечения
}
void Widget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);//очищаем буферцвета и глубины
    //нужно загрузить матрицу проекций  и модельно видовую матрицу в shader
    ViewMatrix1.setToIdentity();
    ViewMatrix2.setToIdentity();
    ViewMatrix1.translate(0.0,0.0,z);//отодвигаем матрицу на 5
    ViewMatrix2.rotate(rotation);
    ViewMatrix=ViewMatrix1*ViewMatrix2;
    program.bind();
    program.setUniformValue("u_projectionMatrix",projectionMatrix);
    program.setUniformValue("u_viewMatrix",ViewMatrix);
    program.setUniformValue("u_lightPosition",QVector4D(0.0,0.0,0.0,1.0));
    program.setUniformValue("u_lightPower",6.0f);
    for(int i=0;i<objects.size();i++)
    {
        objects[i]->draw(&program,context()->functions());
    }
    for(int i=0;i<sections.size();i++)
    {
        sections[i]->draw(&program,context()->functions());
    }
    for(int i=0;i<tracks.size();i++)
    {
        tracks[i]->draw(&program,context()->functions());
    }
    if(isCutting)
    {
        QOpenGLContext *ctx=QOpenGLContext::currentContext();
        if(mFBO)
            delete mFBO;
        QOpenGLFramebufferObjectFormat format;
        format.setSamples(0);
        format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
        mFBO=new QOpenGLFramebufferObject(size(),format);
        glBindFramebuffer(GL_READ_FRAMEBUFFER,defaultFramebufferObject());
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,mFBO->handle());
        ctx->extraFunctions()->glBlitFramebuffer(0,0,width(),height(),0,0,mFBO->width(),mFBO->height(),GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT,GL_NEAREST);
        mFBO->bind();
        float depth;
        if(mouseclick.size()==1 && tr_cutVertexes.size()>0)
        {
            cutVertexes=cutVertexes+tr_cutVertexes;
            tr_cutVertexes.clear();
        }
        for(int i=0;i<mouseclick.size();i++)
        {
            glReadPixels(mouseclick[i].x(),height()-mouseclick[i].y(),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&depth);
            if(depth>=1)
                return;
            float zNorm=2*depth-1;
            float zView=2*0.01*50/((50-0.01)*zNorm-0.01-50);
            depth=zView-z;
            QVector4D tmp(2.0f*mouseclick[i].x()/width()-1.0f,-2.0f*mouseclick[i].y()/height()+1.0f,-1.0f,1.0f);
            QVector4D tmp2((projectionMatrix.inverted()*tmp).toVector2D(),-1.0f,0.0f);//вектор направления клика мышью
            QVector3D direction((ViewMatrix1.inverted()*tmp2).toVector3D().normalized());//вектор направления клика мышью
                                                                                            //в мировой СК
            QVector3D camPos((ViewMatrix1.inverted()*QVector4D(0.0f,0.0f,0.0f,1.0f)).toVector3D());
            QVector3D N(0.0f,0.0f,1.0f);
            float t=QVector3D::dotProduct(QVector3D(camPos.x(),camPos.y(),depth-camPos.z()),N)/QVector3D::dotProduct(direction,N);
            QVector3D result=camPos+direction*t;
            if(i==0)
                cutVertexes.append(result);
            if(i==1)
                tr_cutVertexes.push_front(result);
        }
        mouseclick.clear();
        mFBO->release();
        isCutting=false;
    }
}
void Widget::initShaders()
{
    if(!program.addShaderFromSourceFile(QOpenGLShader::Vertex,":/vshader.vsh"))//здесь + компиляция
        close();//закрыть приложение
    if(!program.addShaderFromSourceFile(QOpenGLShader::Fragment,":/fshader.fsh"))
        close();
    if(!program.link())//объединение шейдеров в один и прокидывает переменные varying
        close();
}
void Widget::loadObj(QString path)
{
    QFile objFile(path);
    QVector<QVector3D> coords;
    QVector<VertexData> vertexes;
    QVector<GLuint> indexes;
    QVector<QString> faces;
    if(!objFile.exists())
    {
        qDebug()<<"Not found";
        return;
    }
    objFile.open(QIODevice::ReadOnly);
    QTextStream input(&objFile);
    while(!input.atEnd())
    {
        QString str=input.readLine();
        QStringList list=str.split(" ");
        if(list[0]=="v")
        {

            coords.append(QVector3D((list[1].toFloat()+60.0f)/50.0f,(list[2].toFloat()-25.0f)/50.0f,(list[3].toFloat()-220.0f)/50.0f));
            //coords.append(QVector3D((list[1].toFloat()),(list[2].toFloat()),(list[3].toFloat())));
            continue;
        }
        if(list[0]=="f")
        {
            faces.append(str);
            QStringList vert1=list[1].split("/");
            QStringList vert2=list[2].split("/");
            QStringList vert3=list[3].split("/");
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            QVector3D a=vertexes[vertexes.size()-3].position;
            QVector3D b=vertexes[vertexes.size()-2].position;
            QVector3D c=vertexes[vertexes.size()-1].position;
            QVector3D n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            QVector3D n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            QVector3D n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            QVector3D norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            a=vertexes[vertexes.size()-3].position;
            b=vertexes[vertexes.size()-2].position;
            c=vertexes[vertexes.size()-1].position;
            n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            continue;
        }
    }
    objFile.close();
    SimpleObject3D* obj=new SimpleObject3D(vertexes,indexes,QImage(":/cube.png"));
    obj->faces=faces;
    obj->coords=coords;
    objects.append(obj);
}

/*bool checkNormal(QVector3D a, QVector3D b, QVector3D c)
{
    QVector3D n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
    QVector3D n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
    QVector3D n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
    QVector3D norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
    float s=QVector3D::dotProduct(norm,QVector3D(0.0,0.0,1.0));
    if(s>0.0f)
        return true;
    else
        return false;
}*/

void Widget::cutter()
{
    if(tr_cutVertexes.size()>0)
    {
        cutVertexes=cutVertexes+tr_cutVertexes;
        tr_cutVertexes.clear();
    }
    if(cutVertexes.size()<3)
    {
        QMessageBox::warning(this,"Warning","You must choose at least 3 vertexes.");
        return;
    }
    int Q=objects.size();
    for(int i=0;i<Q;i++)
    {
        QVector<QVector3D> coords;
        QVector<VertexData> vertexes;
        QVector<GLuint> indexes;
        QVector<QString> faces;
        for(int j=0;j<objects[i]->faces.size();j++)
        {
            QString str=objects[i]->faces[j];
            QStringList list=str.split(" ");
            QStringList vert1=list[1].split("/");
            QStringList vert2=list[2].split("/");
            QStringList vert3=list[3].split("/");
            QVector3D tmp1=ViewMatrix2*objects[i]->coords[vert1[0].toLong()-1];
            QVector3D tmp2=ViewMatrix2*objects[i]->coords[vert2[0].toLong()-1];
            QVector3D tmp3=ViewMatrix2*objects[i]->coords[vert3[0].toLong()-1];
            if(checkBelonging(tmp1.x(),tmp1.y())&&
                    checkBelonging(tmp2.x(),tmp2.y())&&
                    checkBelonging(tmp3.x(),tmp3.y())&&
                    checkDistance(tmp1,tmp2,tmp3))
            {
                faces.append(str);
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert1[0].toLong()-1].x(),objects[i]->coords[vert1[0].toLong()-1].y(),objects[i]->coords[vert1[0].toLong()-1].z()-0.5),QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert2[0].toLong()-1].x(),objects[i]->coords[vert2[0].toLong()-1].y(),objects[i]->coords[vert2[0].toLong()-1].z()-0.5),QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert3[0].toLong()-1].x(),objects[i]->coords[vert3[0].toLong()-1].y(),objects[i]->coords[vert3[0].toLong()-1].z()-0.5),QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
                QVector3D a=vertexes[vertexes.size()-3].position;
                QVector3D b=vertexes[vertexes.size()-2].position;
                QVector3D c=vertexes[vertexes.size()-1].position;
                QVector3D n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
                QVector3D n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
                QVector3D n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
                QVector3D norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
                vertexes[vertexes.size()-3].normal=norm;
                vertexes[vertexes.size()-2].normal=norm;
                vertexes[vertexes.size()-1].normal=norm;
                indexes.append(indexes.size());
                indexes.append(indexes.size());
                indexes.append(indexes.size());
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert3[0].toLong()-1].x(),objects[i]->coords[vert3[0].toLong()-1].y(),objects[i]->coords[vert3[0].toLong()-1].z()-0.5),QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert2[0].toLong()-1].x(),objects[i]->coords[vert2[0].toLong()-1].y(),objects[i]->coords[vert2[0].toLong()-1].z()-0.5),QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
                vertexes.append(VertexData(QVector3D(objects[i]->coords[vert1[0].toLong()-1].x(),objects[i]->coords[vert1[0].toLong()-1].y(),objects[i]->coords[vert1[0].toLong()-1].z()-0.5),QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
                a=vertexes[vertexes.size()-3].position;
                b=vertexes[vertexes.size()-2].position;
                c=vertexes[vertexes.size()-1].position;
                n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
                n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
                n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
                norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
                vertexes[vertexes.size()-3].normal=norm;
                vertexes[vertexes.size()-2].normal=norm;
                vertexes[vertexes.size()-1].normal=norm;
                indexes.append(indexes.size());
                indexes.append(indexes.size());
                indexes.append(indexes.size());
            }
        }
        if(faces.size()!=0)
        {
            coords=objects[i]->coords;
            for(int j=0;j<coords.size();j++)
            {
                coords[j].setZ(coords[j].z()-0.5f);
            }
            SimpleObject3D* obj=new SimpleObject3D(vertexes,indexes,QImage(":/cube2.png"));
            obj->faces=faces;
            obj->coords=coords;
            for(int k=0;k<cutVertexes.size();k++)
            {
                QVector3D tmp=ViewMatrix2.inverted()*cutVertexes[k];
                obj->border.push_back(QVector3D(tmp.x(),tmp.y(),tmp.z()-0.5));
            }
            sections.append(obj);
        }
    }
    update();
}
float isLeft(float _startX, float _startY, float _endX, float _endY, float _pointX, float _pointY)
{
    return ((_endX - _startX) * (_pointY - _startY) - (_pointX - _startX) * (_endY - _startY));
}
bool Widget::checkBelonging(float _pointX, float _pointY)
{
    int windingNumber = 0;
    float startX = 0;
    float startY = 0;
    float endX = 0;
    float endY = 0;
    int count = cutVertexes.size();
    for (int i = 1; i <= count; i++)
    {
        startX = cutVertexes[i-1].x();
        startY = cutVertexes[i-1].y();
        if (i == count)
        {
            endX = cutVertexes[0].x();
            endY = cutVertexes[0].y();
        }
        else
        {
            endX = cutVertexes[i].x();
            endY = cutVertexes[i].y();
        }
        if (startY <= _pointY)
        {
            if (endY > _pointY)
            {
                if (isLeft(startX, startY, endX, endY, _pointX, _pointY) > 0)
                {
                    ++windingNumber;
                }
            }
        }
        else
        {
            if (endY <= _pointY)
            {
                if (isLeft(startX, startY, endX, endY, _pointX, _pointY) < 0)
                {
                    --windingNumber;
                }
            }
        }
    }
    return (windingNumber != 0);
}

bool Widget::checkDistance(QVector3D a, QVector3D b, QVector3D c)
{
    float s=0.0;
    for(int i=0;i<cutVertexes.size();i++)
    {
        for(int j=0;j<cutVertexes.size();j++)
        {
            QVector3D tmp=cutVertexes[i]-cutVertexes[j];
            if(s<tmp.length())
                s=tmp.length();
        }
    }
    for(int i=0;i<cutVertexes.size();i++)
    {
        if((cutVertexes[i]-a).length()>s || (cutVertexes[i]-b).length()>s || (cutVertexes[i]-c).length()>s)
            return false;
    }
    return true;
}

void Widget::finder()
{
    for(int i=0;i<objects.size();i++)
    {
        qDebug()<<"_________";
        for(int j=0;j<objects[i]->coords.size();j++)
        {
            qDebug()<<objects[i]->coords[j];
        }
    }
}

void Widget::connecting(unsigned int a, unsigned int b)
{
    b--;
    a--;
    if(tracks.size()>=a)
    {
        QVector<QVector3D> coords=tracks[a]->coords;
        QVector<QString> faces=tracks[a]->faces;
        QVector<QVector3D> scoords=sections[b]->coords;
        QVector<QString> sfaces=sections[b]->faces;
        QVector<QVector3D> sborder=sections[b]->border;
        QVector<VertexData> vertexes;
        QVector<GLuint> indexes;
        int s=coords.size();
        for(int i=0;i<scoords.size();i++)
        {
            coords.push_back(QVector3D(scoords[i].x(),scoords[i].y(),scoords[i].z()-0.25f));
        }
        for(int i=0;i<sfaces.size();i++)
        {
            QString str=sfaces[i];
            QStringList list=str.split(" ");
            QStringList vert1=list[1].split("/");
            QStringList vert2=list[2].split("/");
            QStringList vert3=list[3].split("/");
            long int q=vert1[0].toLong()+s;
            long int w=vert2[0].toLong()+s;
            long int e=vert3[0].toLong()+s;
            QString res="f "+QString::number(q)+" "+QString::number(w)+" "+QString::number(e);
            faces.push_back(res);
        }
        for(int j=0;j<faces.size();j++)
        {
            QString str=faces[j];
            QStringList list=str.split(" ");
            QStringList vert1=list[1].split("/");
            QStringList vert2=list[2].split("/");
            QStringList vert3=list[3].split("/");
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            QVector3D a=vertexes[vertexes.size()-3].position;
            QVector3D b=vertexes[vertexes.size()-2].position;
            QVector3D c=vertexes[vertexes.size()-1].position;
            QVector3D n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            QVector3D n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            QVector3D n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            QVector3D norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            a=vertexes[vertexes.size()-3].position;
            b=vertexes[vertexes.size()-2].position;
            c=vertexes[vertexes.size()-1].position;
            n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
        }
        SimpleObject3D* obj;
        obj=new SimpleObject3D(vertexes,indexes,QImage(":/cube3.png"));
        obj->faces=faces;
        obj->coords=coords;
        obj->border=sborder;
        tracks.append(obj);
    }
    else
    {
        QVector<QVector3D> coords=sections[b]->coords;
        QVector<VertexData> vertexes;
        QVector<GLuint> indexes;
        QVector<QString> faces=sections[b]->faces;
        QVector<QVector3D> border=sections[b]->border;
        for(int j=0;j<coords.size();j++)
        {
            coords[j].setZ(coords[j].z()-0.25f);
        }
        for(int j=0;j<border.size();j++)
        {
            border[j].setZ(border[j].z()-0.25f);
        }
        for(int j=0;j<faces.size();j++)
        {
            QString str=faces[j];
            QStringList list=str.split(" ");
            QStringList vert1=list[1].split("/");
            QStringList vert2=list[2].split("/");
            QStringList vert3=list[3].split("/");
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            QVector3D a=vertexes[vertexes.size()-3].position;
            QVector3D b=vertexes[vertexes.size()-2].position;
            QVector3D c=vertexes[vertexes.size()-1].position;
            QVector3D n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            QVector3D n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            QVector3D n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            QVector3D norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            vertexes.append(VertexData(coords[vert3[0].toLong()-1],QVector2D(0.0,1.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert2[0].toLong()-1],QVector2D(0.0,0.0),QVector3D(1.0,0.0,0.0)));
            vertexes.append(VertexData(coords[vert1[0].toLong()-1],QVector2D(1.0,1.0),QVector3D(1.0,0.0,0.0)));
            a=vertexes[vertexes.size()-3].position;
            b=vertexes[vertexes.size()-2].position;
            c=vertexes[vertexes.size()-1].position;
            n1=QVector3D(c.x()-a.x(),c.y()-a.y(),c.z()-a.z());
            n2=QVector3D(b.x()-a.x(),b.y()-a.y(),b.z()-a.z());
            n=QVector3D(n1.y()*n2.z()-n1.z()*n2.y(),n1.z()*n2.x()-n1.x()*n2.z(),n1.x()*n2.y()-n1.y()*n2.x());
            norm=QVector3D(-n.x()/n.length(),-n.y()/n.length(),-n.z()/n.length());
            vertexes[vertexes.size()-3].normal=norm;
            vertexes[vertexes.size()-2].normal=norm;
            vertexes[vertexes.size()-1].normal=norm;
            indexes.append(indexes.size());
            indexes.append(indexes.size());
            indexes.append(indexes.size());
        }
        SimpleObject3D* obj;
        obj=new SimpleObject3D(vertexes,indexes,QImage(":/cube3.png"));
        obj->faces=faces;
        obj->coords=coords;
        obj->border=border;
        tracks.append(obj);
    }
}

void Widget::mousePressEvent(QMouseEvent *event)
{
    if(!cutFlag)
    {
        if(event->buttons()==Qt::LeftButton)
            mousePosition=QVector2D(event->localPos());
        event->accept();
    }
    else
    {
        if(event->buttons()==Qt::LeftButton)
        {
            mouseclick.push_back(QVector2D(event->localPos()));
            isCutting=true;
            z+=0.000001f;
            update();
        }
        if(event->buttons()==Qt::RightButton)
        {
            mousePosition=QVector2D(event->localPos());
            event->accept();
        }
    }
}

void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if(!cutFlag)
    {
        if(event->buttons()!=Qt::LeftButton)
            return;
        QVector2D diff=QVector2D(event->localPos())-mousePosition;
        mousePosition=QVector2D(event->localPos());
        float angle=diff.length()/2.0;//длина перемещения мыши/2 (/2 чтобы поворот не был слишком быстрым)
        QVector3D axis=QVector3D(diff.y(),diff.x(),0.0);//ось вращения(перпендик линии перемещения мыши)
                                //по правилам надо поменять коорд местами и у одной знак поменять но в opengl др ск
                                //поэтому не надо знак менять
        rotation=QQuaternion::fromAxisAndAngle(axis,angle)*rotation;
        update();// обновить текущее изображение
    }
    else
    {
        if(event->buttons()!=Qt::RightButton)
            return;
        QVector2D diff=QVector2D(event->localPos())-mousePosition;
        if(diff.length()>6)
        {
            QVector2D p;
            if(diff.x()==0.0f)
                p=QVector2D(1.0,0.0);
            else if(diff.y()==0.0f)
                p=QVector2D(0.0,1.0);
            else
            {
                p=QVector2D(1.0,-diff.x()/diff.y());
                p/=p.length();
            }
            mousePosition=QVector2D(event->localPos());
            mouseclick.push_back(QVector2D(QVector2D(int(event->localPos().x()+5.0f*p.x()),int(event->localPos().y()+5.0f*p.y()))));
            mouseclick.push_back(QVector2D(QVector2D(int(event->localPos().x()-5.0f*p.x()),int(event->localPos().y()-5.0f*p.y()))));
            isCutting=true;
            z+=0.000001f;
            update();
        }
    }
}

void Widget::wheelEvent(QWheelEvent *event)
{
    if(!cutFlag)
    {
        if(event->delta()>0)
        {
            z+=0.25f;
        }
        else if(event->delta()<0)
        {
            z-=0.25f;
        }
        update();
    }
}



