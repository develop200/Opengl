#include "mainwindow.h"
#include <QApplication>
#include <QOpenGLWidget>
#include <QDebug>
#include <QObject>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QSurfaceFormat format;
    format.setVersion(2,1);
    format.setProfile(QSurfaceFormat::CoreProfile);
    format.setDepthBufferSize(32);
    format.setSamples(16);
    QSurfaceFormat::setDefaultFormat(format);
    MainWindow w;
    w.show();
    return a.exec();
}
