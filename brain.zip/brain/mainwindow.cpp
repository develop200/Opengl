#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include "dialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect (this, SIGNAL (updater(QString)),
             ui->openGLWidget, SLOT(loadObj(QString)));
    connect (this, SIGNAL (cutter()),
             ui->openGLWidget, SLOT(cutter()));
    connect (this, SIGNAL (finder()),
             ui->openGLWidget, SLOT(finder()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,
                       tr("Open Mesh"), QDir::currentPath(),
                       tr("Model File(*.obj)"));
    if(!filename.isEmpty())
        emit updater(filename);
}

void MainWindow::on_pushButton_2_clicked()
{
    (ui->openGLWidget)->cutFlag=1;
    (ui->openGLWidget)->cutVertexes.clear();
}

void MainWindow::on_pushButton_3_clicked()
{
    (ui->openGLWidget)->cutFlag=0;
    emit cutter();
}

void MainWindow::on_pushButton_4_clicked()
{
    emit finder();
}

void MainWindow::on_pushButton_5_clicked()
{
    Dialog *d=new Dialog();
    connect (d, SIGNAL (connecting(unsigned int,unsigned int)),
             ui->openGLWidget, SLOT(connecting(unsigned int,unsigned int)));
    d->show();
}
